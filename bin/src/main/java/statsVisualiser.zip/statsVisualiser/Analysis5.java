package statsVisualiser;

/**
 * A subclass of Analysis, this class does not process data and hence requires no overwriting.
 * @author Joseph Siy, Rosy Ren
 */
public class Analysis5 extends Analysis {

	public Analysis5(Selection s) {
		super(s);
	}

}
