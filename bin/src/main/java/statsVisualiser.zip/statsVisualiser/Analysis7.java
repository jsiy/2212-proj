package statsVisualiser;

/**
 * A subclass of Analysis, this class does not process data and hence requires no overwriting.
 * @author Joseph Siy, Rosy Ren
 */
public class Analysis7 extends Analysis {

	public Analysis7(Selection s) {
		super(s);
	}

}
