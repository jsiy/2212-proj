package statsVisualiser;

public class Selection {
	public Selection() {
		
	}

}
