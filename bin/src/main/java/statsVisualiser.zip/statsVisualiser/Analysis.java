package statsVisualiser;

import java.util.ArrayList;

/**
 * The super class of all 8 analysis methods. Contains a generic doAnalysis() method that simply passes along data. This generic method can be overwritten in sub classes should we need to process the data.
 * This class also exists to employ the strategy (and indirectly facade) design patterns.
 * @author Joseph Siy, Rosy Ren
 *
 */
public class Analysis{
	/**
	 * The selection for which we perform analysis
	 */
	private Selection selection;
	
	/**
	 * The constructor; simply creates an object with the specified selection
	 * @param s the specified selection
	 */
	public Analysis(Selection s){
		this.selection = s;
	}
	
	/**
	 * The doAnalysis method will by default pass along data; subclasses may overwrite this.
	 * @return
	 */
	public ArrayList<ArrayList<DataItem>> doAnalysis(){
		Data data = new Data();
		return Data.getData(selection);
	}
}
